from django.apps import AppConfig


class MachineAppConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'Machine_app'
